import React from "react";

const Settings: React.FC = () => {
  return <h1 className="text-2xl font-bold">Settings Page</h1>;
};

export default Settings;
