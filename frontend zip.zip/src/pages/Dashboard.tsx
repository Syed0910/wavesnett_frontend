import React from "react";
import DashboardCards from "./BarChart"; // rename for clarity

const Dashboard: React.FC = () => {
  return (
    <div >
      <DashboardCards />
    </div>
  );
};

export default Dashboard;
